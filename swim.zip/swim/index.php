<!DOCTYPE html>
<html lang="en-US" class="no-js">


<!-- Mirrored from astritbublaku.com/demos/onepagepro/creative/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Jul 2018 05:55:50 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <title>Swim Care</title>
    <link rel="stylesheet"  href="css/bootstrap.min.css">
    <link rel='stylesheet'  href='css/google-fonts.css' type='text/css' media='all' />
    <!-- <link rel='stylesheet'  href='css/fonts.css' type='text/css' media='all' /> -->
    <!-- <linl rel="stylesheet"  href="css/form.css"> -->
    <link rel='stylesheet'  href='revslider/public/assets/css/settings.css' type='text/css' media='all'>
    <link rel='stylesheet'  href='css/style.css' type='text/css' media='all' />
    <link rel='stylesheet'  href='css/onepagepro-style-custom.css' type='text/css' media='all' />
    
    <link rel='stylesheet'  href='css/page-builder.css' type='text/css' media='all' />
    <link rel="stylesheet"  type="text/css" href="quform/css/base.css" />

    <!--[if lt IE 9]> <script type='text/javascript' src='https://cdn.goodlayers.com/onepagepro/corporate/wp-content/themes/onepagepro/js/html5.js?ver=4.9.6'></script> <![endif]-->


</head>


<body data-rsssl=1 class="home page-template-default page page-id-3999 gdlr-core-body onepagepro-body onepagepro-body-front onepagepro-full  onepagepro-with-sticky-navigation gdlr-core-link-to-lightbox">
    <div class="onepagepro-mobile-header-wrap ">
        <div class="onepagepro-mobile-header onepagepro-header-background onepagepro-style-slide" id="onepagepro-mobile-header">
            <div class="onepagepro-mobile-header-container onepagepro-container">
                <div class="onepagepro-logo  onepagepro-item-pdlr">
                    <div class="onepagepro-logo-inner">
                        <a href="index.html"><img src="upload/logo.png" alt="" width="150" height="26" /></a>
                    </div>
                </div>
                <div class="onepagepro-mobile-menu-right">
                    <div class="onepagepro-mobile-menu"><a class="onepagepro-mm-menu-button onepagepro-mobile-menu-button onepagepro-mobile-button-hamburger" href="#onepagepro-mobile-menu"><span></span></a>
                        <div class="onepagepro-mm-menu-wrap onepagepro-navigation-font" id="onepagepro-mobile-menu" data-slide="right">
                            <ul id="menu-main-menu" class="m-menu">
                                <li class="menu-item "><a href="#home">Home</a></li>
                                <li class="menu-item "><a href="#about">About</a></li>
                                 <li class="menu-item "><a href="#product">Products</a></li>
                                <li class="menu-item "><a href="#events">Events</a></li>
                                 <li class="menu-item "><a href="#contact">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="onepagepro-body-outer-wrapper ">
        <div class="onepagepro-body-wrapper clearfix  onepagepro-with-transparent-header onepagepro-with-frame">
            <div class="onepagepro-header-background-transparent">
                <header class="onepagepro-header-wrap onepagepro-header-style-plain  onepagepro-style-menu-right onepagepro-sticky-navigation onepagepro-style-slide" data-navigation-offset="75px">
                    <div class="onepagepro-header-background"></div>
                    <div class="onepagepro-header-container  onepagepro-container">
                        <div class="onepagepro-header-container-inner clearfix">
                            <div class="onepagepro-logo  onepagepro-item-pdlr">
                                <div class="onepagepro-logo-inner">
                                    <a href="index.html"><img src="upload/logo.png" 
                                        alt="Swim Care"></a>
                                </div>
                            </div>
                            <div class="onepagepro-navigation onepagepro-item-pdlr clearfix onepagepro-navigation-submenu-indicator ">
                                <div class="onepagepro-main-menu" id="onepagepro-main-menu">
                                    <ul id="menu-main-menu-1" class="sf-menu">
                                        <li class="menu-item  onepagepro-normal-menu"><a href="#home">Home</a></li>
                                         <li class="menu-item  onepagepro-normal-menu"><a href="#about">About</a></li>
                                         <li class="menu-item  onepagepro-normal-menu"><a href="#product">Products</a></li>
                                        <li class="menu-item  onepagepro-normal-menu"><a href="#events">Events</a></li>
                                        <li class="menu-item  onepagepro-normal-menu"><a href="#contact">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
            <div class="onepagepro-page-wrapper" id="onepagepro-page-wrapper">
                <div class="gdlr-core-page-builder-body">
                    <div class="gdlr-core-pbf-wrapper " style="padding: 0px 0px 0px 0px;" id="home">
                        <div class="gdlr-core-pbf-background-wrap" style="background-color: #383838 ;"></div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-pbf-wrapper-full-no-space">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-revolution-slider-item gdlr-core-item-pdlr gdlr-core-item-pdb " style="padding-bottom: 0px;">
                                        <div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery" style="margin:0px auto;background:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
                                            <div id="rev_slider_1_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.5.1">
                                                <ul>
                                                    <li data-index="rs-1" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-thumb="upload/slider-1-100x50.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description=""> <img src="upload/slider-1.jpg" alt="" title="slider-1" width="1800" height="892" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
                                                       
                                                    </li>
                                                    <li data-index="rs-2" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-thumb="upload/slider-2-100x50.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description=""> <img src="upload/slider-2.jpg" alt="" title="slider-2" width="1800" height="892" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
                                                    </li>
                                                </ul>

                                                <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding:28px 0px 30px 0px;" id="about">
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-element">
                                    <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr">
                                        <div class="
                                            gdlr-core-title-item-title-wrap">
                                            <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" style="font-size: 58px;font-weight: 600;letter-spacing: 0px;text-transform: none;"><span class="gdlr-core-title-item-side-border gdlr-core-skin-divider gdlr-core-left" style="border-color: #2ab9da;"  ></span>About
                                             <span class="gdlr-core-title-item-side-border gdlr-core-skin-divider gdlr-core-right" style="border-color: #38bedc;"></span></h3>
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding:50px 0px 50px 0px;">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js" style="background:#f3f3f3;" data-parallax-speed="0.1"></div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js ">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-image-item gdlr-core-item-pdlr gdlr-core-item-pdb  gdlr-core-center-align">
                                                    <div class="gdlr-core-image-item-wrap gdlr-core-media-image  gdlr-core-image-item-style-rectangle" style="border-width: 0px;">
                                                        <a class="gdlr-core-ilightbox gdlr-core-js " href="https://player.vimeo.com/video/280321142?title=0&amp;byline=0&amp;portrait=0" data-type="iframe" data-options="width: 1280, height: 720"><img src="upload/video-image.jpg" alt="" width="1200" height="724" /><span class="gdlr-core-image-overlay gdlr-core-no-hover gdlr-core-transparent gdlr-core-round-icon"><i class="gdlr-core-image-overlay-icon fa fa-play gdlr-core-size-22" style="background-color: #2aaada ;"  ></i></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gdlr-core-pbf-column gdlr-core-column-30">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js " style="padding:65px 0px 0px 25px;">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 5px;">
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr">
                                                    <div class="gdlr-core-title-item-title-wrap">
                                                        <h3 class="gdlr-core-title-item-title gdlr-core-skin-title" style="font-size: 40px;letter-spacing: 0px;text-transform: none;">About Swim Care</h3></div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 20px;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 16px;">
                                                        <p>Impact Labs Pvt Ltd was established in 1987 with a vision of becoming a leading provider of quality health and pharmaceutical products. Swim Care is an extension of our vision. We are proud to bring you world class skin, hair and dental care products for anyone who enjoys swimming. </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product-bdg" id="product" style="background-image: url(upload/blog-bg.jpg);background-size: cover;background-position: center;" 
                            data-parallax-speed="0.3">
                         <div class="product-title">
                            <h2>Our Products</h2>
                         </div>
                        <div class="container">
                            <div class="product-content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div onmouseover="rotateYDIV()" class="product-cat">
                                            <img src="upload/product_1.png">
                                        </div>
                                        <div class="product-desc">
                                            <p>
                                                Swim Care Swim and Sport Bath Wash protects the skin from the harsh side effects of chlorine, salts and other minerals in the swimming pools. It’s formula is enhanced with Aloe Vera extracts, Pro-vitamin B5 and Vitamin E that penetrate the skin and keep it moisturized throughout the day.
                                            </p>
                                        </div>
                                        <div class="product-btn">
                                            <button  type="button" class="btn-product-info">
                                              <a href="https://www.amazon.in/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=swim+care">Buy Now</a>
                                            </button>
                                        </div>
                                        <!--  -->
                                    </div>
                                    <div class="col-md-4">
                                        <div onmouseover="rotateYDIV()" class="product-cat">
                                            <img src="upload/product_2.png">
                                        </div>
                                        <div class="product-desc">
                                            <p>
                                                Don’t let sports come in the way of having a great hair day! Swim Care Chlorine & Odour Clear Shampoo has been enhanced with Aloe Vera extracts, Pro-Vitamin B5 and Vitamin E to nourish your hair while it gently removes all the chlorine buildup and the unpleasant smells from your scalp and hair.
                                            </p>
                                        </div>
                                        <div class="product-btn">
                                            <button  type="button" class="btn-product-info">
                                              <a href="https://www.amazon.in/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=swim+care"> Buy Now</a>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div onmouseover="rotateYDIV()" class="product-cat">
                                            <img src="upload/product_3.png">
                                        </div>
                                        <div class="product-desc">
                                            <p>
                                                Exposure to chemically treated swimming pool water can leave teeth sensitive, discolored and with enamel damage. Swim Care Toothpaste formula has been carefully developed to fight off germs and protect teeth from exposure to chlorine and other minerals.Continued daily use will help protect enamel.
                                            </p>
                                        </div>
                                        <div class="product-btn">
                                            <button  type="button" class="btn-product-info">
                                              <a href="https://www.amazon.in/s/ref=nb_sb_noss_2?url=search-alias%3Daps&field-keywords=swim+care"> Buy Now</a>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>    
                     </div>
                    <div class="gdlr-core-pbf-wrapper " style="padding: 70px 0px 56px 0px;">
                        <div class="gdlr-core-pbf-background-wrap">
                            <div class="gdlr-core-pbf-background gdlr-core-parallax gdlr-core-js" style="background-image: url(upload/mobile-bg-1.jpg);background-size: cover;background-position: center;" data-parallax-speed="0.2"></div>
                        </div>
                        <div class="gdlr-core-pbf-wrapper-content gdlr-core-js ">
                            <div class="gdlr-core-pbf-wrapper-container clearfix gdlr-core-container">
                                <div class="gdlr-core-pbf-column gdlr-core-column-30 gdlr-core-column-first">
                                    <div class="gdlr-core-pbf-column-content-margin gdlr-core-js " style="padding: 45px 0px 0px 0px;">
                                        <div class="gdlr-core-pbf-column-content clearfix gdlr-core-js ">
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-title-item gdlr-core-item-pdb clearfix  gdlr-core-left-align gdlr-core-title-item-caption-top gdlr-core-item-pdlr" style="padding-bottom: 15px;">
                                                    <div class="gdlr-core-title-item-title-wrap text-swim">
                                                        <h3 class="gdlr-core-title-item-title  gdlr-core-skin-title" style="font-size: 53px;letter-spacing: 0px;text-transform: none;">Why Swim Care ?</h3></div>
                                                </div>
                                            </div>
                                            <div class="gdlr-core-pbf-element">
                                                <div class="gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-left-align" style="padding-bottom: 20px;">
                                                    <div class="gdlr-core-text-box-item-content" style="font-size: 18px;">
                                                        <p>Swimming is more than a sport! It is a fun healthy lifestyle that can be practiced by people of all ages and across fitness levels. It is a low-impact workout that promotes endurance, strength and flexibility. Like any form of exercise it is advisable to keep in mind the safety precautions necessary to make swimming an enjoyable experience. All public swimming pools add a mix of chlorine solution and bleaching agents to maintain clean pool water.Swim Care is a line of world class skin, hair and dental care products that protect swimmers from the detrimental effects of the chemicals in the pool water. All our products are designed specifically keeping the hair care,skin care and dental care needs of swimmers.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="gdlr-core-pbf-wrapper " style="padding: 15px 0px 5px 0px;" data-skin="testimonial" id="events">
                        <div class="events" style="background-color: #f5f5f5 ;">
                            <div class="container">
                                <div class="events-title" style="margin-bottom: 40px;">
                                    <h3 style="font-size: 56px;text-transform: none;letter-spacing: 0px;padding-top:20px;text-align: center;">
                                        Events
                                    </h3>
                                </div>
                                <div class="events-content">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="events-img">
                                                <img src="upload/event1.png">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="events-info">
                                                <p><span style="padding-right:10px;"><b>Event Name:</b></span>Jamnabai Inter-school Swimming Event</p>
                                                <p><span style="padding-right:10px;"><b>Venue:</b></span>Ozone Swimming Pool (Goregaon West)</p>
                                                <p><span style="padding-right:10px;"><b>Date:</b></span>11th Sep 2017 & 12th Sep 2017</p>
                                                <p><span style="padding-right:10px;"><b>Day:</b></span> Monday & Tuesday</p>
                                                <p><span style="padding-right:10px;"><b>Time:</b></span>7:30am to 12:30pm</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="events-info">
                                                <p><span style="padding-right:10px;"><b>Event Name:</b></span>Jamnabai Inter-school Swimming Event</p>
                                                <p><span style="padding-right:10px;"><b>Venue:</b></span>Ozone Swimming Pool (Goregaon West)</p>
                                                <p><span style="padding-right:10px;"><b>Date:</b></span>11th Sep 2017 & 12th Sep 2017</p>
                                                <p><span style="padding-right:10px;"><b>Day:</b></span> Monday & Tuesday</p>
                                                <p><span style="padding-right:10px;"><b>Time:</b></span>7:30am to 12:30pm</p>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="events-img">
                                                <img src="upload/event2.png">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>    
                    </div>
                    <div class="contact" id="contact">
                        <div class="container">
                            <h3>Contact Us</h3>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="contact-content">
                                        <div class="contact-social-icon">
                                            <img src="upload/email.png">
                                            <p>info@swimcare.in</p>
                                        </div>
                                        <div class="contact-social-icon">
                                            <img src="upload/call.png">
                                            <p>+91-9136275504</p>
                                        </div>
                                        <div class="social-icons">
                                            <ul>
                                                <li><a href="https://plus.google.com/u/0/112329869295740309546"><img src="upload/google-plus.png"></a></li>
                                                <li><a href="https://www.facebook.com/Swim-Care-197932670890615/"><img src="upload/facebook.png"></a></li>
                                                <li><a href="https://www.instagram.com/swimcareindia/?hl=en"><img src="upload/instagram.png"></a></li>
                                                <li><a href="https://twitter.com/impact_pvt"><img src="upload/twitter.png"></a></li>
                                                <!-- <li><a href=" https://www.linkedin.com/in/impact-labs-pvt-ltd-323316147/"><img src="upload/linkedin.png"></a></li> -->
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="contact-content-call">
                                        <!-- <h4>Enquire Now</h4> -->
                                        <form enctype="multipart/form-data" method="post">
                                          <div class="form-group">
                                              <input type="name" class="form-control" id="name" placeholder="Enter Full Name" name="name" required>
                                            </div>
                                            <div class="form-group">
                                              <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                                            </div>
                                            <div class="form-group">
                                              <input type="number" class="form-control" id="num" placeholder="Enter Number" name="phone" required>
                                            </div>
                                            <div class="form-group">
                                                <textarea class="form-control" id="msg" placeholder="Message" name="msg" style="height:200px;" required></textarea>
                                            </div>
                                            <div class="contact-btn">
                                                <button type="submit" class="btn-swim" name="submit_contact" id="submit_contact">Submit</button>
                                            </div>    
                                        </form>

                                        <?php


                                            if(isset($_REQUEST['submit_contact'])){

                                            $fname = $_REQUEST['name']; 
                                            //$lname = $_REQUEST['l_name']; 
                                            $email1 = $_REQUEST['email']; 
                                            $phone1 = $_REQUEST['phone']; 

                                            $note1 = $_REQUEST['msg']; 



                                            $to = 'mauryarohit002@gmail.com';
                                            $subject = "swim care Enquiry Box";

                                            $htmlContent = '<meta name="viewport" content="width=device-width, initial-scale=1.0" />


                                            <table width="300" border="1"><tr><td colspan="2"><h1>swim care</h1></td></tr><tr><td>Name</td><td>'.$fname.'</td></tr><tr><td>Email</td><td>'.$email1.'</td></tr><tr><td>Phone</td><td>'.$phone1.'</td></tr><tr><td>Message</td><td>'.$note1.'</td></tr></table>';

                                            // Set content-type header for sending HTML email
                                            $headers = "MIME-Version: 1.0" . "\r\n";
                                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                                            // Additional headers
                                            $headers .= 'From:swim-care.in' . "\r\n";


                                            // Send email
                                            if(mail($to,$subject,$htmlContent,$headers))
                                                {?>
                                                <script>
                                                    alert("Thank you for Contacting Us. We'll revert to you soon!.");
                                                </script>    
                                              <?php 
                                            } 
                                            else {?>
                                            <script>
                                                    alert("Email sending fail.");
                                            </script>
                                            <?php 
                                             }
                                              
                                            

                                            }
                                            ?>



                                    </div>      
                                </div>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type='text/javascript' src='js/jquery/jquery.js'></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='revslider/public/assets/js/jquery.themepunch.tools.min.js'></script>
   <!--   <script type="text/javascript" src="js/form.js"></script> -->
    <script type='text/javascript' src='revslider/public/assets/js/jquery.themepunch.revolution.min.js'></script>
    <script type='text/javascript' src='js/jquery/ui/effect.min.js'></script>
    <script type='text/javascript'>
        var onepagepro_script_core = {
            "home_url": "index.html\/"
        };
    </script>
    <script type='text/javascript' src='js/scripts.js'></script>
    <script type='text/javascript' src='js/combine.min.js'></script>
    <script type='text/javascript'>
        var gdlr_core_pbf = {
            "admin": "",
            "video": {
                "width": "640",
                "height": "360"
            },
            "ajax_url": "",
            "ilightbox_skin": "dark"
        };

        

    </script>
    <script type='text/javascript' src='js/page-builder.js'></script>
    <script type="text/javascript" src="quform/js/plugins.js"></script>

    <script type="text/javascript" src="quform/js/scripts.js"></script>


    <script type="text/javascript" src="revslider/public/assets/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script type="text/javascript" src="revslider/public/assets/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script type="text/javascript" src="revslider/public/assets/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script type="text/javascript" src="revslider/public/assets/js/extensions/revolution.extension.navigation.min.js"></script>
    <script type="text/javascript" src="revslider/public/assets/js/extensions/revolution.extension.parallax.min.js"></script>   
    <script>
        /*<![CDATA[*/
        var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
        var htmlDivCss = "";
        if (htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        } else {
            var htmlDiv = document.createElement("div");
            htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
            document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
        } /*]]>*/
    </script>
    <script>
        /*<![CDATA[*/
        var htmlDiv = document.getElementById("rs-plugin-settings-inline-css");
        var htmlDivCss = "";
        if (htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        } else {
            var htmlDiv = document.createElement("div");
            htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
            document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
        } /*]]>*/
    </script>
    <script type="text/javascript">
        /*<![CDATA[*/

        var revapi1, tpj = jQuery;
        tpj(document).ready(function() {
            if (tpj("#rev_slider_1_1").revolution == undefined) {
                revslider_showDoubleJqueryError("#rev_slider_1_1");
            } else {
                revapi1 = tpj("#rev_slider_1_1").show().revolution({
                    sliderType: "standard",
                    jsFileLocation: "revslider/public/assets/js/",
                    sliderLayout: "auto",
                    dottedOverlay: "none",
                    delay: 9000,
                    navigation: {
                        keyboardNavigation: "off",
                        keyboard_direction: "horizontal",
                        mouseScrollNavigation: "off",
                        mouseScrollReverse: "default",
                        onHoverStop: "off",
                        bullets: {
                            enable: true,
                            hide_onmobile: false,
                            style: "uranus",
                            hide_onleave: false,
                            direction: "horizontal",
                            h_align: "center",
                            v_align: "bottom",
                            h_offset: 0,
                            v_offset: 35,
                            space: 10,
                            tmp: '<span class="tp-bullet-inner"></span>'
                        }
                    },
                    visibilityLevels: [1240, 1024, 778, 480],
                    gridwidth: 1280,
                    gridheight: 868,
                    lazyType: "none",
                    parallax: {
                        type: "mouse",
                        origo: "enterpoint",
                        speed: 400,
                        speedbg: 0,
                        speedls: 0,
                        levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 51, 55],
                        disable_onmobile: "on"
                    },
                    shadow: 0,
                    spinner: "spinner0",
                    stopLoop: "off",
                    stopAfterLoops: -1,
                    stopAtSlide: -1,
                    shuffle: "off",
                    autoHeight: "off",
                    disableProgressBar: "on",
                    hideThumbsOnMobile: "off",
                    hideSliderAtLimit: 0,
                    hideCaptionAtLimit: 0,
                    hideAllCaptionAtLilmit: 0,
                    debugMode: false,
                    fallbacks: {
                        simplifyAll: "off",
                        nextSlideOnWindowFocus: "off",
                        disableFocusListener: false,
                    }
                });
            }
        }); /*]]>*/
    </script>
    <script>
        /*<![CDATA[*/
        var htmlDivCss = unescape("%23rev_slider_1_1%20.uranus%20.tp-bullet%7B%0A%20%20border-radius%3A%2050%25%3B%0A%20%20box-shadow%3A%200%200%200%202px%20rgba%28255%2C%20255%2C%20255%2C%200%29%3B%0A%20%20-webkit-transition%3A%20box-shadow%200.3s%20ease%3B%0A%20%20transition%3A%20box-shadow%200.3s%20ease%3B%0A%20%20background%3Atransparent%3B%0A%20%20width%3A15px%3B%0A%20%20height%3A15px%3B%0A%7D%0A%23rev_slider_1_1%20.uranus%20.tp-bullet.selected%2C%0A%23rev_slider_1_1%20.uranus%20.tp-bullet%3Ahover%20%7B%0A%20%20box-shadow%3A%200%200%200%202px%20rgba%28255%2C%20255%2C%20255%2C1%29%3B%0A%20%20border%3Anone%3B%0A%20%20border-radius%3A%2050%25%3B%0A%20%20background%3Atransparent%3B%0A%7D%0A%0A%23rev_slider_1_1%20.uranus%20.tp-bullet-inner%20%7B%0A%20%20-webkit-transition%3A%20background-color%200.3s%20ease%2C%20-webkit-transform%200.3s%20ease%3B%0A%20%20transition%3A%20background-color%200.3s%20ease%2C%20transform%200.3s%20ease%3B%0A%20%20top%3A%200%3B%0A%20%20left%3A%200%3B%0A%20%20width%3A%20100%25%3B%0A%20%20height%3A%20100%25%3B%0A%20%20outline%3A%20none%3B%0A%20%20border-radius%3A%2050%25%3B%0A%20%20background-color%3A%20rgb%28255%2C%20255%2C%20255%29%3B%0A%20%20background-color%3A%20rgba%28255%2C%20255%2C%20255%2C%200.3%29%3B%0A%20%20text-indent%3A%20-999em%3B%0A%20%20cursor%3A%20pointer%3B%0A%20%20position%3A%20absolute%3B%0A%7D%0A%0A%23rev_slider_1_1%20.uranus%20.tp-bullet.selected%20.tp-bullet-inner%2C%0A%23rev_slider_1_1%20.uranus%20.tp-bullet%3Ahover%20.tp-bullet-inner%7B%0A%20transform%3A%20scale%280.4%29%3B%0A%20-webkit-transform%3A%20scale%280.4%29%3B%0A%20background-color%3Argb%28255%2C%20255%2C%20255%29%3B%0A%7D%0A");
        var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
        if (htmlDiv) {
            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
        } else {
            var htmlDiv = document.createElement('div');
            htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
            document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
        } /*]]>*/
    </script>
    <script type="text/javascript">
        /*<![CDATA[*/
        function revslider_showDoubleJqueryError(sliderID) {
            var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
            errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
            errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
            errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
            errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
            jQuery(sliderID).show().html(errorMessage);
        } /*]]>*/
    </script>   

</body>

<!-- Mirrored from astritbublaku.com/demos/onepagepro/creative/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Jul 2018 05:58:41 GMT -->
</html>